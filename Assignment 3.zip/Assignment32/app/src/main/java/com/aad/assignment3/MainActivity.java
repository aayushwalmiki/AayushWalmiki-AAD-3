package com.aad.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button home,about,course;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        home = findViewById(R.id.home);
        about = findViewById(R.id.about);
        course = findViewById(R.id.course);



        Intent ihome,iaboutus,icourse;
        ihome = new Intent(MainActivity.this,home.class);
        iaboutus = new Intent(MainActivity.this,Aboutus.class);
        icourse = new Intent(MainActivity.this, Course.class);


//On Clicking the HOME button, takes you to the "home" activity
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(ihome);
            }
        });

        //On clicking the aboutus button, takes you to the about us page
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { startActivity(iaboutus); }
        });

        //On clicking "COURSE" button, takes you to the course page
        course.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {startActivity(icourse);}
        });
    }

}
