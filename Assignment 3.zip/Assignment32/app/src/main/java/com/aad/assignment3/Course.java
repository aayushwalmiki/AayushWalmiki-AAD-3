package com.aad.assignment3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Course extends AppCompatActivity {
    ListView list;
    ArrayList<String> courses = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course);


        list = findViewById(R.id.list);



        courses.add("Mathematics 1");
        courses.add("English");
        courses.add("Physics");
        courses.add("Constitution of India");
        courses.add("Chemistry");
        courses.add("Engineering Graphics and Design");
        courses.add("Communication Skills");
        courses.add("Basic Electrical Engineering");
        courses.add("Mathematics 2");
        courses.add("Programming of Problem Solving");
        courses.add("Workshop");
        courses.add("Managing Uncertainty");
        courses.add("ETL");
        courses.add("Data Structures and ALgos");
        courses.add("Data Handling and Visualization");
        courses.add("Mathematics 1");
        courses.add("Information Security and Privacy");
        courses.add("Optimization Methods");
        courses.add("Eco");
        courses.add("SSDI");
        courses.add("STPA");
        courses.add("Android App Development");
        courses.add("Database Management System");
        courses.add("IDSA");
        courses.add("MAE");
        courses.add("EVS");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1,courses);
        list.setAdapter(adapter);
    }
}